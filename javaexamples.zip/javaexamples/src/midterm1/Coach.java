//Mirjana Bijelic 2019230099//
//Midterm 1 project//
package midterm1;


public class Coach {
    String  name;
    String lastname;

    public Coach(String name, String lastname) {
        this.name = name;
        this.lastname = lastname;
    }
    
    public Coach() {
    }
   
    
}
