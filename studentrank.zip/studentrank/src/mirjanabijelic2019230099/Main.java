//Mirjana Bijelic 2019230099//
//Homework number 1, exercise 1//
package mirjanabijelic2019230099;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
        StudentRank temp = new StudentRank();
        StudentRank[] sArr = new StudentRank[3];
        for (int i = 0; i < sArr.length; i++) {
            System.out.printf(" %d. Student is: ", i+1);
            sArr[i] = new StudentRank();
            sArr[i].studentName = scan.nextLine();
            sArr[i].testOne = scan.nextInt();
            sArr[i].testTwo = scan.nextInt();
            scan.nextLine();
        }

        for (int i = 0; i < sArr.length; i++) {
            for (int j = i+1; j < sArr.length; j++) {
                if(sArr[i].tests() < sArr[j].tests()){
                    temp = sArr[i];
                    sArr[i] = sArr[j];
                    sArr[j] = temp;
                }
            }
        }
        
    System.out.print("The rank (best, middle, worst) of these students is: ");
        for (int i = 0; i < sArr.length ; i++) {
            if(i != sArr.length - 1){
                System.out.print(sArr[i].studentName + ", ");}
            else{
                System.out.println(sArr[i].studentName);}
    
        }
    }
}
